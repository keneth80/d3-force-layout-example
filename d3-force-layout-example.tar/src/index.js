import './style.css';

import { DocumentSelectionExample } from './component/document-selection-example';
import { excute } from './component/d3-force-layout-dag-component';

// const excute = () => {
//     const documentSelectionExample = new DocumentSelectionExample();
// };

excute();